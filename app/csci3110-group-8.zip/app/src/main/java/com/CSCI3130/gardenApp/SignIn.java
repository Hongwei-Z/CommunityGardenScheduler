package com.CSCI3130.gardenApp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

//activity allows user to sign in
public class SignIn extends AppCompatActivity {

    //UI element declarations
    EditText emailTxt, passwordTxt;
    Button logInBtn, signUpBtn;

    //firebase authentication object
    FirebaseAuth mFirebaseAuth;
    //state listener
    FirebaseAuth.AuthStateListener mAuthStateListener;

    @Override
    protected void onStart() {
        super.onStart();

        //sets up authorization listener
        mFirebaseAuth.addAuthStateListener(mAuthStateListener);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        //UI element assignments
        emailTxt = (EditText) findViewById(R.id.emailTxt_signin);
        passwordTxt = (EditText) findViewById(R.id.passwordTxt_signin);
        logInBtn = (Button) findViewById(R.id.logInBtn_signin);
        signUpBtn = (Button) findViewById(R.id.signUpBtn_signin);

        //get instance for firebase authentication
        mFirebaseAuth = FirebaseAuth.getInstance();

        //check if anyone is logged in
        checkLoginState();
    }

    //check if anyone is logged in through this method
    public void checkLoginState(){
        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser mFirebaseUser = mFirebaseAuth.getCurrentUser();

                //if logged in, go to welcome screen
                if( mFirebaseUser != null ){
                    Toast.makeText(SignIn.this,"You are logged in",Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(SignIn.this, Welcome.class);
                    startActivity(i);
                }

                //if not logged in, prompt user to log in
                else{
                    Toast.makeText(SignIn.this,"Please Log In or Sign Up",Toast.LENGTH_SHORT).show();
                }
            }
        };
    }

    //onclick function for log in button (wrapper)
    public void LogIn_onclick (View v){
        LogInFirebase();
    }

    //function logs into firebase using given credentials
    public void LogInFirebase(){

        //get text from email/password fields
        String email = emailTxt.getText().toString();
        String pass = passwordTxt.getText().toString();

        //makes sure the email and password aren't blank
        if(email.isEmpty()){
            emailTxt.setError("Please enter email id");
            emailTxt.requestFocus();
        }
        else  if(pass.isEmpty()){
            passwordTxt.setError("Please enter your password");
            passwordTxt.requestFocus();
        }
        else  if(email.isEmpty() && pass.isEmpty()){
            Toast.makeText(SignIn.this,"Please enter your password and email.",Toast.LENGTH_SHORT).show();
        }

        //if neither field is empty, try to log in
        else  if(!(email.isEmpty() && pass.isEmpty())){

            //run signin method for firebase
            mFirebaseAuth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(SignIn.this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {

                    //if login is not successful, return error
                    if(!task.isSuccessful()){
                        Toast.makeText(SignIn.this,"Login Error, Please Login Again",Toast.LENGTH_SHORT).show();
                    }

                    //if login is successful, go to login page
                    else{
                        Intent i = new Intent(SignIn.this, Welcome.class);
                        startActivity(i);
                    }
                }
            });
        }
        else{
            Toast.makeText(SignIn.this,"Error Occurred!",Toast.LENGTH_SHORT).show();

        }

    }



}
